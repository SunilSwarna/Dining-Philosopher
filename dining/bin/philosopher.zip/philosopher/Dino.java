package philosopher;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.*;
import java.lang.*;
import java.lang.Thread.*; 

public class Dino extends JApplet {
	public Dino() {
	}
 private static final int CANVAS_SIZE = 800;

 private void start(final RootPaneContainer pane, final boolean isApplet) {
     final Coordinator c = new Coordinator();
     final Table t = new Table(c, CANVAS_SIZE);
     try {
         SwingUtilities.invokeAndWait(new Runnable() {
             public void run() {
                 new UI(pane, c, t, isApplet);
             }
         });
     } catch (Exception e) {
         System.err.println("unable to create GUI");
     }
 }
 public void init() {
     start(this, true);
 }
 public static void main(String[] args) {
     JFrame f = new JFrame("Dining");
     f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     Dino me = new Dino();
     me.start(f, false);
     f.pack();            // calculate size of frame
     f.setVisible(true);
 }
}

class Fork {
 private Table t;
 private static final int XSIZE = 10;
 private static final int YSIZE = 10;
 private int orig_x;
 private int orig_y;
 private int x;
 private int y;
 public Fork(Table T, int cx, int cy) {
     t = T;
     orig_x = cx;
     orig_y = cy;
     x = cx;
     y = cy;
 }

 public void reset() {
     clear();
     x = orig_x;
     y = orig_y;
     t.repaint();
 }

 public void acquire(int px, int py) {
     clear();
     x = (orig_x + px)/2;
     y = (orig_y + py)/2;
     t.repaint();
 }

 public void release() {
     reset();
 }
 public void draw(Graphics g) {
     g.setColor(Color.CYAN);
     g.fillRect(230,220,340,340);
     g.setColor(Color.YELLOW);
     g.fillOval(360, 360, 80, 80);
 }
 // erase self
 //
 private void clear() {
     Graphics g = t.getGraphics();
     g.setColor(t.getBackground());
  //   g.fillOval(x-XSIZE/2, y-YSIZE/2, XSIZE, YSIZE);
 }
}

class Philosopher extends Thread {
 private static final Color THINK_COLOR = Color.YELLOW;
 private static final Color WAIT_COLOR = Color.red;
 private static final Color EAT_COLOR = Color.green;
 private static final double THINK_TIME = 12.0;
 private static final double HUNGER_TIME = 6.0;
 private static final double EAT_TIME = 1.5;
 private Coordinator c;
 private Table t;
 private static final int XSIZE = 100;
 private static final int YSIZE = 100;
 private int x;
 private int y;
 private Fork left_fork;
 private Fork right_fork;
 private Random prn;
 private Color color;
 public Philosopher(Table T, int cx, int cy,
                    Fork lf, Fork rf, Coordinator C) {
     t = T;
     x = cx;
     y = cy;
     left_fork = lf;
     right_fork = rf;
     c = C;
     prn = new Random();
     color = THINK_COLOR;
 }
 public void run() {
     for (;;) {
         try {
             if (c.gate()) 
            	 delay(EAT_TIME);
             think();
             if (c.gate()) 
            	 delay(THINK_TIME);
             hunger();
             if (c.gate()) delay(HUNGER_TIME);
             eat();
         } catch(ResetException e) { 
             color = THINK_COLOR;
             t.repaint();
         }
     }
 }
 public void draw(Graphics g) {
     g.setColor(color);
     g.fillOval(x-XSIZE/2, y-YSIZE/2, XSIZE, YSIZE);
 }
 private static final double FUDGE = 0.2;
 private void delay(double secs) throws ResetException {
     double ms = 1000 * secs;
     int window = (int) (2.0 * ms * FUDGE);
     int add_in = prn.nextInt() % window;
     int original_duration = (int) ((1.0-FUDGE) * ms + add_in);
     int duration = original_duration;
     for (;;) {
         try {
             Thread.sleep(duration);
             return;
         } catch(InterruptedException e) {
             if (c.isReset()) {
                 throw new ResetException();
             } else {        
                 c.gate();   
                 duration = original_duration / 2;
             }
         }
     }
 }

 private void think() throws ResetException {
     color = THINK_COLOR;
     t.repaint();
     delay(THINK_TIME);
 }

 private void hunger() throws ResetException {
     color = WAIT_COLOR;
     t.repaint();
     delay(HUNGER_TIME);
     left_fork.acquire(x, y);
     yield();    
     right_fork.acquire(x, y);
 }

 private void eat() throws ResetException {
     color = EAT_COLOR;
     t.repaint();
     delay(EAT_TIME);
     left_fork.release();
     yield();    
     right_fork.release();
 }
}

class Table extends JPanel {
 private static final int NUM_PHILS = 5;

 private final Coordinator c;
 private Fork[] forks;
 private Philosopher[] philosophers;

 public void pause() {
     c.pause();
     for (int i = 0; i < NUM_PHILS; i++) {
         philosophers[i].interrupt();
     }
 }
 public void reset() {
     c.reset();
     for (int i = 0; i < NUM_PHILS; i++) {
         philosophers[i].interrupt();
     }
     for (int i = 0; i < NUM_PHILS; i++) {
         forks[i].reset();
     }
 }
 public void paintComponent(Graphics g) {
     super.paintComponent(g);

     for (int i = 0; i < NUM_PHILS; i++) {
         forks[i].draw(g);
         philosophers[i].draw(g);
     }
     g.setColor(Color.black);
     g.drawRect(0, 0, getWidth()-1, getHeight()-1);
 }
 public Table(Coordinator C, int CANVAS_SIZE) 
 {
     c = C;
     forks = new Fork[NUM_PHILS];
     philosophers = new Philosopher[NUM_PHILS];
     setPreferredSize(new Dimension(CANVAS_SIZE, CANVAS_SIZE));

     for (int i = 0; i < NUM_PHILS; i++) {
         double angle = Math.PI/2 + 2*Math.PI/NUM_PHILS*(i-0.5);
         forks[i] = new Fork(this,
             (int) (CANVAS_SIZE/2.0 + CANVAS_SIZE/6.0 * Math.cos(angle)),
             (int) (CANVAS_SIZE/2.0 - CANVAS_SIZE/6.0 * Math.sin(angle)));
     }
     for (int i = 0; i < NUM_PHILS; i++) {
         double angle = Math.PI/2 + 2*Math.PI/NUM_PHILS*i;
         philosophers[i] = new Philosopher(this,
             (int) (CANVAS_SIZE/2.0 + CANVAS_SIZE/3.0 * Math.cos(angle)),
             (int) (CANVAS_SIZE/2.0 - CANVAS_SIZE/3.0 * Math.sin(angle)),
             forks[(i+1)% NUM_PHILS],
             forks[i],
             c);
         philosophers[i].start();
     }
 }
}

class ResetException extends Exception { };

class Coordinator {
 public enum State { PAUSED, RUNNING, RESET }
 private State state = State.PAUSED;

 public synchronized boolean isPaused() {
     return (state == State.PAUSED);
 }

 public synchronized void pause() {
     state = State.PAUSED;
 }

 public synchronized boolean isReset() {
     return (state == State.RESET);
 }

 public synchronized void reset() {
     state = State.RESET;
 }

 public synchronized void resume() {
     state = State.RUNNING;
     notifyAll();       
 }
 public synchronized boolean gate() throws ResetException {
     if (state == State.PAUSED || state == State.RESET) {
         try {
             wait();
         } catch(InterruptedException e) {
             if (isReset()) {
                 throw new ResetException();
             }
         }
         return true;        
     }
     return false;           
 }
}
class UI extends JPanel {
 private final Coordinator c;
 private final Table t;

 private final JRootPane root;
 private static final int externalBorder = 6;

 private static final int stopped = 0;
 private static final int running = 1;
 private static final int paused = 2;

 private int state = stopped;

 public UI(RootPaneContainer pane, Coordinator C, Table T,
           boolean isApplet) {
     final UI u = this;
     c = C;
     t = T;

     final JPanel b = new JPanel();

     final JButton runButton = new JButton("Run");
     final JButton pauseButton = new JButton("Pause");
     final JButton resetButton = new JButton("Reset");
     final JButton quitButton = new JButton("Quit");

     runButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             c.resume();
             root.setDefaultButton(pauseButton);
         }
     });
     pauseButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             c.pause();
             root.setDefaultButton(runButton);
         }
     });
     resetButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
             t.reset();
             root.setDefaultButton(runButton);
         }
     });
     if (!isApplet) {
         quitButton.addActionListener(new ActionListener() {
             public void actionPerformed(ActionEvent e) {
                 System.exit(0);
             }
         });
     }
     b.setLayout(new FlowLayout());
     b.add(runButton);
     b.add(pauseButton);
     b.add(resetButton);
     if (!isApplet) {
         b.add(quitButton);
     }
     setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
     setBorder(BorderFactory.createEmptyBorder(
         externalBorder, externalBorder, externalBorder, externalBorder));
     add(t);
     add(b);
     pane.getContentPane().add(this);
     root = getRootPane();
     root.setDefaultButton(runButton);
 }
}