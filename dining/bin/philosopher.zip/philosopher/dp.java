package philosopher;

public class dp {

}
