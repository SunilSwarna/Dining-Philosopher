package philosopher;

import javax.swing.JApplet;
import javax.swing.JFrame;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;

//import philosopher.Launch.Phil;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Panel;
import javax.swing.JEditorPane;
import javax.swing.JRadioButton;

public class dinp extends JPanel {
	String [] str = new String[5];
	private JButton btnRun;
	private JRadioButton rdbtnNewRadioButton;
	private JRadioButton rdbtnNewRadioButton_1;
	private JRadioButton rdbtnNewRadioButton_2;
	private JRadioButton rdbtnNewRadioButton_3;
	private JRadioButton rdbtnNewRadioButton_4;
	public static void main(String[] args)
	{
		dinp d =new dinp();
		JFrame j = new JFrame();
		j.setTitle("Dining Philosopher");
		j.setSize(600, 400);
		j.setVisible(true);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.getContentPane().add(d);
	}
	class Launch{
		int num,i;
		semaphore [] chopstick ;
		Phil [] phil;
		semaphore mutex;
		/* Array of philosophers */
	//String ws = "";
	Launch()
	{
		num=5;						                      /* Total philosophers */
		chopstick = new semaphore[num];               /* Total Chopsticks */
		   mutex = new semaphore(1);                     /* Chopstick not occupied- initialised as 1 */
		 phil = new Phil[num];
		 i=0;
		 for(;i<num;i++)									
			{
				chopstick[i]=new semaphore(1);						          /* Giving All chopsticks value as 1 - not occupied */
				phil[i]=new Phil(i);								          /* Initialising philosophers array */
				phil[i].start();									          /* Starting the simulation */
			}
		//return ws;
	}
	class Phil extends Thread
	{
		int id;
		String Status="";
		int quantum=2087;
		Phil (int x)
		{
			id=x;
			Status="Hungry";
		}
		public void run()
		{
			int i=0,j=0;
				while(j<10)
				{
				mutex.Wait_for_turn();						           /* Giving indication that chopstick is occupied */
				chopstick[id].Wait_for_turn();				           /* Left chopstick is occupied */
				chopstick[(id+1)%(num)].Wait_for_turn();         /* Right Chopstick is occupied */
				Status="Eating";
				PrintStatus();
				
				int timequantum=(int)(Math.random()*quantum);			       /* Eating time */
				try
				{
					Thread.sleep(timequantum);
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				chopstick[id].pick_the_chopsticks();				       /* Left chopstick is free */
				chopstick[(id+1)%(num)].pick_the_chopsticks();   /* Right Chopstick is free */
				Status="Thinking";
				PrintStatus();
				mutex.pick_the_chopsticks();					           /* Indication that chopstick is free */
				timequantum=(int)(Math.random()*quantum);			           /* Thinking Time */
				try
				{
					Thread.sleep(timequantum);
				}	
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
				Status="Hungry";
				PrintStatus();
				}
		}
		public void PrintStatus()
		{	
				int ko=0;
				String sw = "";
				for(int i=0;i<num;i++)
				{
					sw+=phil[i].Status+" ";
					if(phil[i].Status=="Eating")
					{
						ko=i;
					}
				}
			//	System.out.println(sw);
				String [] ew=sw.split(" ");
				System.out.println(ew[0]);
				if(phil[0].Status=="Eating")
				{
					rdbtnNewRadioButton_1.setSelected(true);
					rdbtnNewRadioButton.setSelected(true);
					rdbtnNewRadioButton_4.setSelected(false);
					rdbtnNewRadioButton_2.setSelected(false);
					rdbtnNewRadioButton_3.setSelected(false);
					
				}
				else if(phil[1].Status=="Eating")
				{
					rdbtnNewRadioButton_1.setSelected(true);
					rdbtnNewRadioButton_2.setSelected(true);
					rdbtnNewRadioButton.setSelected(false);
					rdbtnNewRadioButton_4.setSelected(false);
					rdbtnNewRadioButton_3.setSelected(false);
				}
				else if(phil[2].Status=="Eating")
				{
					rdbtnNewRadioButton_2.setSelected(true);
					rdbtnNewRadioButton_3.setSelected(true);
					rdbtnNewRadioButton.setSelected(false);
					rdbtnNewRadioButton_1.setSelected(false);
					rdbtnNewRadioButton_4.setSelected(false);
				}
				else if(phil[3].Status=="Eating")
				{
					rdbtnNewRadioButton_2.setSelected(false);
					rdbtnNewRadioButton_4.setSelected(false);
					rdbtnNewRadioButton_1.setSelected(false);
					rdbtnNewRadioButton_3.setSelected(true);
					rdbtnNewRadioButton_4.setSelected(true);
				}
				else if(phil[4].Status=="Eating")
				{
					rdbtnNewRadioButton_4.setSelected(true);
					rdbtnNewRadioButton.setSelected(true);
					rdbtnNewRadioButton_1.setSelected(false);
					rdbtnNewRadioButton_2.setSelected(false);
					rdbtnNewRadioButton.setSelected(false);
				}
				
				
		//		ws+=sw;
				
	//		return ws;
			//System.out.println(ws);
		}
	//	System.out.println(Status);
	}
	}

	public dinp() {
		setLayout(null);
		
		btnRun = new JButton("Run");
		btnRun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Launch qe=new Launch();
				
			}
		});
		btnRun.setBounds(12, 262, 97, 25);
		add(btnRun);
		
		JButton btnStop = new JButton("Stop");
		btnStop.setBounds(341, 262, 97, 25);
		add(btnStop);
		
	    rdbtnNewRadioButton = new JRadioButton("");
		rdbtnNewRadioButton.setBounds(242, 78, 127, 25);
		add(rdbtnNewRadioButton);
		
		rdbtnNewRadioButton_1 = new JRadioButton("");
		rdbtnNewRadioButton_1.setBounds(130, 40, 127, 25);
		add(rdbtnNewRadioButton_1);
		
		 rdbtnNewRadioButton_2 = new JRadioButton("");
		rdbtnNewRadioButton_2.setBounds(80, 138, 127, 25);
		add(rdbtnNewRadioButton_2);
		
		 rdbtnNewRadioButton_3 = new JRadioButton("");
		rdbtnNewRadioButton_3.setBounds(164, 217, 127, 25);
		add(rdbtnNewRadioButton_3);
		
		rdbtnNewRadioButton_4 = new JRadioButton("");
		rdbtnNewRadioButton_4.setBounds(264, 174, 127, 25);
		add(rdbtnNewRadioButton_4);
		
		
		
	}

	/**
	 * Create the applet.
	 */
	
	
}

